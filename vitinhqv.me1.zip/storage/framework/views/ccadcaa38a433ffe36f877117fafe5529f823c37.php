<!DOCTYPE html>
<html lang="vi">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">

    <title>[Admin] Laptop - In <?php echo e($tieude1); ?></title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Roboto', sans-serif;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }
        #tenCuaHang{
            font-size: 40px;
            font-weight: bold
        }
    </style>

</head>

<body class="login-page" style="background: white">

    <div>
        <div class="row">
            <div class="col-xs-7" style="font-family:'Roboto', sans-serif;">
                <p id="tenCuaHang">Laptop QV</p>
                <b>SĐT:</b> 090.xxx.xnxx (Mr. V) - 090.xxx.xnxx (Mr. Q) <br>
                <b>EMAIL</b>: supportlaptop@vitinhqv.me<br>
                <b>ĐỊA CHỈ:</b>180 Đ. Cao Lỗ, Phường 4, Quận 8, Thành phố Hồ Chí Minh<br>
                <br>
            </div>

            <div class="col-xs-4" style="text-align: center;">
                <img width="215" height="75"
                    src="<?php echo e(asset('user/images/menu/logo/1.jpg')); ?>" />
                <img width="120" height="100" title="test" src="data:image/png;base64, <?php echo base64_encode(QrCode::generate( $loai == 'PN' ? 'PN'.$phieupdf->maphieunhap :'PX' . $phieupdf->maphieuxuat)); ?>" />
            </div>
        </div>

        <div style="margin-bottom: 0px">&nbsp;</div>
        <?php
            $ngay = Carbon\Carbon::parse($phieupdf->ngaytao);
        ?>
        <div class="row" style="font-family:'Roboto'; text-align: center;margin-bottom: 3.5rem;">
            <h2 style="font-weight: bold">PHIẾU <?php echo e($tieude); ?></h2>
            <div style="text-align: center; margin-bottom: 2%;margin-top: -1%;font-size: 9pt">
                Mã phiếu: <?php echo e($loai); ?><?php echo e($loai == 'PN' ? $phieupdf->maphieunhap : $phieupdf->maphieuxuat); ?><br>
                Ngày <?php echo e($ngay->format('d')); ?> tháng <?php echo e($ngay->format('m')); ?> năm <?php echo e($ngay->format('Y')); ?>

            </div>
        </div>

        <div class="row" style="margin-bottom: 3%;font-size: 10pt">
            <div class="col-xs-6">
                <b><?php echo e($loai == 'PN' ? 'Nhà cung cấp' : 'Họ và tên'); ?>:</b>
                <?php echo e($loai == 'PN' ? $phieupdf->j_nguoidung->hoten : $phieupdf->hotennguoinhan); ?><br>
                <b>SĐT:</b>
                <?php echo e($loai == 'PN' ? $phieupdf->j_nguoidung->sodienthoai : $phieupdf->sodienthoainguoinhan); ?><br>
                <b>Địa chỉ:</b> <?php echo e($loai == 'PN' ? $phieupdf->j_nguoidung->diachi : $phieupdf->diachinguoinhan); ?>

            </div>
            <div class="col-xs-6">
                <?php if($loai == 'PN'): ?>
                    <b>Mã NCC:</b> ND<?php echo e($phieupdf->manguoidung); ?><br>
                <?php else: ?>
                    <b>Hình thức:</b> <?php echo e($phieupdf->hinhthucthanhtoan == 0 ? 'Tiền mặt' : 'ATM'); ?><br>
                    <b>Tình trạng:</b>
                    <?php if($phieupdf->tinhtranggiaohang == 0): ?>
                        Đã hủy
                    <?php elseif($phieupdf->tinhtranggiaohang == 1): ?>
                        Chờ xác nhận
                    <?php elseif($phieupdf->tinhtranggiaohang == 2): ?>
                        Đang chuẩn bị hàng
                    <?php elseif($phieupdf->tinhtranggiaohang == 3): ?>
                        Đang giao hàng
                    <?php else: ?>
                        Đã giao thành công
                    <?php endif; ?>
                    <br>
                <?php endif; ?>
                <b>Ghi chú:</b> <?php echo e($phieupdf->ghichu); ?>

            </div>
        </div>
        <table class="table" style="font-family:'Roboto';">
            <thead style="background: #F5F5F5;">
                <tr>
                    <th class="text-center">STT</th>
                    <th class="text-center">Sản phẩm</th>
                    <th class="text-center">Số lượng</th>
                    <th class="text-center">Đơn giá</th>
                    <th class="text-right">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $chitietphieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($key+1); ?></td>
                        <td>SP<?php echo e($ct->masanpham); ?> | <?php echo e($ct->j_chitietphieu_sp->tensanpham); ?></td>
                        <td class="text-center"><?php echo e($ct->soluong); ?></td>
                        <td class="text-center"><?php echo e(number_format($ct->dongia)); ?></td>
                        <td class="text-right"><?php echo e(number_format($ct->soluong * $ct->dongia)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="row">
            <div class="col-xs-6"></div>
            <div class="col-xs-5">
                <table style="width: 100%">
                    <tbody>
                        <tr class="well" style="padding: 5px">
                            <th style="padding: 5px">
                                <div>Tổng tiền</div>
                            </th>
                            <td style="padding: 5px" class="text-right"><?php echo e(number_format($phieupdf->tongtien)); ?></td>
                        </tr>
                        <tr class="well" style="padding: 5px">
                            <th style="padding: 5px">
                                <div>Đã thanh toán</div>
                            </th>
                            <td style="padding: 5px" class="text-right">
                                <?php echo e(number_format($phieupdf->tongtien - $phieupdf->congno)); ?></td>
                        </tr>
                        <tr class="well" style="padding: 5px">
                            <th style="padding: 5px">
                                <div>Công nợ</div>
                            </th>
                            <td style="padding: 5px" class="text-right"><?php echo e(number_format($phieupdf->congno)); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div style="margin-bottom: 6%">&nbsp;</div>

        <div class="row">
            <table style="width: 100%" class="text-center">
                <tr>
                    <td>Ngày <?php echo e($ngay->format('d') + 10); ?> tháng <?php echo e($ngay->format('m')); ?> năm
                        <?php echo e($ngay->format('Y')); ?></td>
                    <td>Ngày <?php echo e($ngay->format('d') + 10); ?> tháng <?php echo e($ngay->format('m')); ?> năm
                        <?php echo e($ngay->format('Y')); ?></td>
                </tr>
                <tr>
                    <td>Người giao hàng</td>
                    <td>Người nhận hàng</td>
                </tr>
            </table>
        </div>

</body>

</html>
<?php /**PATH C:\Users\Pi Pj\Downloads\new\vitinhqv\resources\views/Admin/pdf.blade.php ENDPATH**/ ?>