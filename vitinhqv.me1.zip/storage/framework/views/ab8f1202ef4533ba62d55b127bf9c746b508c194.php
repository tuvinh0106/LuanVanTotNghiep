<div class="col-sm mb-2 mb-sm-0">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-no-gutter">
            <li class="breadcrumb-item"><a class="breadcrumb-link" href="javascript:;">Sản Phẩm</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($tieude); ?></li>
        </ol>
    </nav>


</div>


<?php /**PATH C:\Users\Pi Pj\Downloads\new\vitinhqv\resources\views/Admin/inc/inc_row.blade.php ENDPATH**/ ?>