<!-- Begin Lis Breadcrumb Area -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="breadcrumb-content">
            <ul>
                <li><a href="<?php echo e(route('trangchu.index')); ?>">Trang Chủ</a></li>
                <?php echo request()->is('chi-tiet-san-pham/*') ? '<li><a href="#">Laptop</a></li>' : ''; ?>

                <?php echo request()->is('bai-viet-*') ? '<li><a href="#">Bài Viết</a></li>' : ''; ?>

                <li class="active"><?php echo e($tieude); ?></li>
            </ul>
        </div>
    </div>
</div>
<!-- Lis Breadcrumb Area End Here -->
<?php /**PATH C:\xampp\htdocs\laptopshop\resources\views/User/inc/nav.blade.php ENDPATH**/ ?>