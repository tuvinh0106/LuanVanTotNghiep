<?php
    $title = $id == 'laptop' ? 'Laptop' : 'Phụ Kiện';
?>
<?php $__env->startSection('title', '' . $tieude . ''); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('User.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Begin Lis Content Wraper Area -->
    <div class="content-wraper pt-60 pb-60 pt-sm-30">
        <div class="container">
            <div class="row mb-30">
                <div class="col-lg-12">
                    <!-- Begin Lis Banner Area -->
                    <div class="single-banner shop-page-banner">
                        <a href="#">
                            <img src="<?php echo e(asset('user/images/banner/bannersp.jpg')); ?>" alt="Li's Static Banner">
                        </a>
                    </div>
                    <!-- Lis Banner Area End Here -->
                </div>
            </div>
            <div class="row">
                <div class="col-lg-<?php echo e($id == 'laptop' ? '9' : '12'); ?> order-1 order-lg-2">
                    <!-- shop-top-bar start -->
                    <div class="shop-top-bar">
                        <div class="shop-bar-inner">
                            <div class="product-view-mode">
                                <!-- shop-item-filter-list start -->
                                <ul class="nav shop-item-filter-list" role="tablist">
                                    <li class="active" role="presentation"><a aria-selected="true" class="active show"
                                            data-toggle="tab" role="tab" aria-controls="grid-view" href="#grid-view"><i
                                                class="fa fa-th"></i></a></li>
                                    <li role="presentation"><a data-toggle="tab" role="tab" aria-controls="list-view"
                                            href="#list-view"><i class="fa fa-th-list"></i></a></li>
                                </ul>
                                <!-- shop-item-filter-list end -->
                            </div>
                            <div class="toolbar-amount">
                                <span>Tổng sản phẩm (<?php echo e(count($sanpham)); ?>)</span>
                            </div>
                        </div>
                        <!-- product-select-box start -->
                        <div class="product-select-box">
                            <div class="product-short">
                                <p>Sắp Xếp:</p>
                                <?php
                                    $sapXep = isset($_GET['sap-xep']) ? $_GET['sap-xep'] : '';
                                    $sapXepLaptop = isset($_GET['sapxep']) ? $_GET['sapxep'] : '';
                                ?>
                                <?php if(isset($_GET['loaiTimKiem'])): ?>
                                    <select id="sapxepsp" class="nice-select">
                                        <option <?php echo e($sapXep == 'moinhat' ? 'selected' : ''); ?>

                                            value="<?php echo e(url()->current()); ?>?loaiTimKiem=<?php echo e($_GET['loaiTimKiem']); ?>&tukhoa=<?php echo e($_GET['tukhoa']); ?>&sap-xep=moinhat">
                                            Mới Nhất</option>
                                        <option <?php echo e($sapXep == 'banchay' ? 'selected' : ''); ?>

                                            value="<?php echo e(url()->current()); ?>?loaiTimKiem=<?php echo e($_GET['loaiTimKiem']); ?>&tukhoa=<?php echo e($_GET['tukhoa']); ?>&sap-xep=banchay">
                                            Bán chạy nhất</option>
                                        <option <?php echo e($sapXep == 'uudai' ? 'selected' : ''); ?>

                                            value="<?php echo e(url()->current()); ?>?loaiTimKiem=<?php echo e($_GET['loaiTimKiem']); ?>&tukhoa=<?php echo e($_GET['tukhoa']); ?>&sap-xep=uudai">
                                            Ưu đãi</option>
                                        <option <?php echo e($sapXep == 'giatang' ? 'selected' : ''); ?>

                                            value="<?php echo e(url()->current()); ?>?loaiTimKiem=<?php echo e($_GET['loaiTimKiem']); ?>&tukhoa=<?php echo e($_GET['tukhoa']); ?>&sap-xep=giatang">
                                            Giá tăng dần</option>
                                        <option <?php echo e($sapXep == 'giagiam' ? 'selected' : ''); ?>

                                            value="<?php echo e(url()->current()); ?>?loaiTimKiem=<?php echo e($_GET['loaiTimKiem']); ?>&tukhoa=<?php echo e($_GET['tukhoa']); ?>&sap-xep=giagiam">
                                            Giá giảm dần</option>
                                    </select>
                                <?php else: ?>
                                    <?php if($id == 'laptop'): ?>

                                        <?php if(isset($_GET['loc'])): ?>
                                            <select id="sapxepsp" class="nice-select">
                                                <option <?php echo e($sapXepLaptop == 'moinhat' ? 'selected' : ''); ?> value="moinhat">
                                                    Mới
                                                    Nhất</option>
                                                <option <?php echo e($sapXepLaptop == 'banchay' ? 'selected' : ''); ?> value="banchay">
                                                    Bán
                                                    chạy nhất</option>
                                                <option <?php echo e($sapXepLaptop == 'uudai' ? 'selected' : ''); ?> value="uudai">
                                                    Ưu
                                                    đãi
                                                </option>
                                                <option <?php echo e($sapXepLaptop == 'giatang' ? 'selected' : ''); ?> value="giatang">
                                                    Giá
                                                    tăng dần</option>
                                                <option <?php echo e($sapXepLaptop == 'giagiam' ? 'selected' : ''); ?> value="giagiam">
                                                    Giá
                                                    giảm dần</option>
                                            </select>
                                        <?php else: ?>
                                            <select id="sapxepsp" class="nice-select">
                                                <option <?php echo e($sapXep == 'moinhat' ? 'selected' : ''); ?>

                                                    value="<?php echo e(Request::url()); ?>?loai=0&sap-xep=moinhat">Mới Nhất
                                                </option>
                                                <option <?php echo e($sapXep == 'banchay' ? 'selected' : ''); ?>

                                                    value="<?php echo e(Request::url()); ?>?loai=0&sap-xep=banchay">Bán chạy
                                                    nhất</option>
                                                <option <?php echo e($sapXep == 'uudai' ? 'selected' : ''); ?>

                                                    value="<?php echo e(Request::url()); ?>?loai=0&sap-xep=uudai">Ưu đãi
                                                </option>
                                                <option <?php echo e($sapXep == 'giatang' ? 'selected' : ''); ?>

                                                    value="<?php echo e(Request::url()); ?>?loai=0&sap-xep=giatang">Giá tăng
                                                    dần</option>
                                                <option <?php echo e($sapXep == 'giagiam' ? 'selected' : ''); ?>

                                                    value="<?php echo e(Request::url()); ?>?loai=0&sap-xep=giagiam">Giá giảm
                                                    dần</option>
                                            </select>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <select id="sapxepsp" class="nice-select">
                                            <option <?php echo e($sapXep == 'moinhat' ? 'selected' : ''); ?>

                                                value="<?php echo e(Request::url()); ?>?loai=1&sap-xep=moinhat">Mới Nhất
                                            </option>
                                            <option <?php echo e($sapXep == 'banchay' ? 'selected' : ''); ?>

                                                value="<?php echo e(Request::url()); ?>?loai=1&sap-xep=banchay">Bán chạy nhất
                                            </option>
                                            <option <?php echo e($sapXep == 'uudai' ? 'selected' : ''); ?>

                                                value="<?php echo e(Request::url()); ?>?loai=1&sap-xep=uudai">Ưu đãi</option>
                                            <option <?php echo e($sapXep == 'giatang' ? 'selected' : ''); ?>

                                                value="<?php echo e(Request::url()); ?>?loai=1&sap-xep=giatang">Giá tăng dần
                                            </option>
                                            <option <?php echo e($sapXep == 'giagiam' ? 'selected' : ''); ?>

                                                value="<?php echo e(Request::url()); ?>?loai=1&sap-xep=giagiam">Giá giảm dần
                                            </option>
                                        </select>

                                    <?php endif; ?>
                                <?php endif; ?>

                            </div>
                        </div>
                        <!-- product-select-box end -->
                    </div>
                    <!-- shop-top-bar end -->
                    <!-- shop-products-wrapper start -->
                    <div class="shop-products-wrapper">
                        <div class="tab-content">
                            <div id="grid-view" class="tab-pane fade active show" role="tabpanel">
                                <div class="product-area shop-product-area">
                                    <div class="row">
                                        <?php if(count($sanpham) > 0): ?>
                                            <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $hinh = explode('|', $sp->hinh);
                                                ?>
                                                <div
                                                    class="<?php echo e($id == 'laptop' ? 'col-lg-4' : 'col-lg-3'); ?> col-md-4 col-sm-6 mt-40">
                                                    <!-- single-product-wrap start -->
                                                    <div class="single-product-wrap">
                                                        <div class="product-image">
                                                            <a href="<?php echo e(route('chitiet', $sp->masanpham)); ?>">
                                                                <img src="<?php echo e(asset('uploads/sanpham/' . $hinh[0])); ?>"
                                                                    alt="Li's Product Image">
                                                            </a>
                                                            <?php if(isset($sp->malaptop)): ?>
                                                                <?php
                                                                    if (isset($sp->tinhtrang)) {
                                                                        $tinhtrang = $sp->tinhtrang;
                                                                    } else {
                                                                        $tinhtrang = '';
                                                                    }
                                                                ?>
                                                                <span
                                                                    class="<?php echo e($tinhtrang == 0 ? 'sticker' : 'sticker-old'); ?>">
                                                                    <?php echo e($tinhtrang == 0 ? 'Mới' : 'Cũ'); ?>

                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="product_desc">
                                                            <div class="product_desc_info">
                                                                <div class="product-review">
                                                                    <h5 class="manufacturer">
                                                                        <a
                                                                            href="shop-left-sidebar.html"><?php echo e(isset($sp->malaptop) ? 'Laptop' : 'Phụ Kiện'); ?></a>
                                                                    </h5>
                                                                    <div class="rating-box">
                                                                        <h5 class="manufacturer">
                                                                            <a href="#">SP<?php echo e($sp->masanpham); ?></a>
                                                                        </h5>
                                                                    </div>
                                                                </div>
                                                                <h4><a class="product_name"
                                                                        href="<?php echo e(route('chitiet', $sp->masanpham)); ?>"><?php echo e($sp->tensanpham); ?></a>
                                                                </h4>
                                                                <div class="price-box">
                                                                    <?php if($sp->giaban > 0): ?>
                                                                        <?php if($sp->giakhuyenmai > 0): ?>
                                                                            <span
                                                                                class="new-price new-price-2"><?php echo e(number_format($sp->giakhuyenmai)); ?></span>
                                                                            <span
                                                                                class="old-price"><?php echo e(number_format($sp->giaban)); ?></span>
                                                                        <?php else: ?>
                                                                            <span
                                                                                class="new-price new-price-2"><?php echo e(number_format($sp->giaban)); ?></span>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <span class="new-price new-price-2">Liên Hệ</span>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="add-actions">
                                                                <ul class="add-actions-link">
                                                                    <input type="hidden"
                                                                        class="soLuongGh<?php echo e($sp->masanpham); ?>"
                                                                        value="1">
                                                                    <li class="add-cart active"><a class="clickThemGh"
                                                                            data-id_gh="<?php echo e($sp->masanpham); ?>"
                                                                            href="#">Thêm Gi<b>ỏ</b> Hàng</a></li>
                                                                    <li><a class="links-details clickThemYt" href="#"
                                                                            data-id_yeuThich="<?php echo e($sp->masanpham); ?>"><i
                                                                                class="fa fa-heart-o"></i></a></li>
                                                                    <li><a href="<?php echo e(route('chitiet', $sp->masanpham)); ?>"
                                                                            data-count="<?php echo e(count($hinh)); ?>"
                                                                            title="quick view" class="quick-view-btn"
                                                                            data-quick_id="<?php echo e($sp->masanpham); ?>"><i
                                                                                class="fa fa-eye"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- single-product-wrap end -->
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <style>
                                                .div-search {
                                                    text-align: center;
                                                    margin-top: 4rem;
                                                    margin-bottom: 4rem;
                                                }

                                                .img-search {
                                                    max-width: 100%;
                                                    position: relative;
                                                    overflow: hidden;
                                                    flex: 1 0 auto;
                                                    display: flex;
                                                    cursor: unset;
                                                    z-index: 0;
                                                    margin: auto;
                                                    border-radius: 0px;
                                                    width: 200px;
                                                    content-visibility: auto;
                                                    height: 200px !important;
                                                }

                                                .title-seach {
                                                    margin-top: 1.5rem;
                                                    font-size: 1rem;
                                                }
                                            </style>
                                            <div class="div-search col-12">
                                                <div height="200" width="200" class="img-search">
                                                    <img src="<?php echo e(asset('user/images/no-products-found.png')); ?>">
                                                </div>
                                                <div class="title-seach">Không tìm thấy sản phẩm nào</div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div id="list-view" class="tab-pane fade product-list-view" role="tabpanel">
                                <div class="row">
                                    <div class="col">
                                        <?php if(count($sanpham) > 0): ?>
                                            <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $hinh = explode('|', $sp->hinh);
                                                ?>
                                                <div class="row product-layout-list">
                                                    <div class="col-lg-3 col-md-5 ">
                                                        <div class="product-image">
                                                            <a href="<?php echo e(route('chitiet', $sp->masanpham)); ?>">
                                                                <img src="<?php echo e(asset('uploads/sanpham/' . $hinh[0])); ?>"
                                                                    alt="Li's Product Image">
                                                            </a>
                                                            <?php if(isset($sp->malaptop)): ?>
                                                                <?php
                                                                    if (isset($sp->tinhtrang)) {
                                                                        $tinhtrang = $sp->tinhtrang;
                                                                    } else {
                                                                        $tinhtrang = '';
                                                                    }
                                                                ?>
                                                                <span
                                                                    class="<?php echo e($tinhtrang == 0 ? 'sticker' : 'sticker-old'); ?>">
                                                                    <?php echo e($tinhtrang == 0 ? 'Mới' : 'Cũ'); ?>

                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-5 col-md-7">
                                                        <div class="product_desc">
                                                            <div class="product_desc_info">
                                                                <div class="product-review">
                                                                    <h5 class="manufacturer">
                                                                        <a
                                                                            href="product-details.html"><?php echo e(isset($sp->malaptop) ? 'Laptop' : 'Phụ Kiện'); ?></a>
                                                                    </h5>
                                                                    <div class="rating-box">
                                                                        <h5 class="manufacturer">
                                                                            <a href="#">SP<?php echo e($sp->masanpham); ?></a>
                                                                        </h5>
                                                                    </div>
                                                                </div>
                                                                <h4><a class="product_name"
                                                                        href="<?php echo e(route('chitiet', $sp->masanpham)); ?>"><?php echo e($sp->tensanpham); ?></a>
                                                                </h4>
                                                                <div class="price-box">
                                                                    <?php if($sp->giaban > 0): ?>
                                                                        <?php if($sp->giakhuyenmai > 0): ?>
                                                                            <span
                                                                                class="new-price new-price-2"><?php echo e(number_format($sp->giakhuyenmai)); ?></span>
                                                                            <span
                                                                                class="old-price"><?php echo e(number_format($sp->giaban)); ?></span>
                                                                        <?php else: ?>
                                                                            <span
                                                                                class="new-price new-price-2"><?php echo e(number_format($sp->giaban)); ?></span>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <span class="new-price new-price-2">Liên Hệ</span>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <p><?php echo substr($sp->mota, 0, 42); ?><?php echo e(strlen($sp->mota) > 42 ? '...' : ''); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <div class="shop-add-action mb-xs-30">
                                                            <ul class="add-actions-link">
                                                                <input type="hidden"
                                                                    class="soLuongGh<?php echo e($sp->masanpham); ?>" value="1">
                                                                <li class="add-cart"><a class="clickThemGh"
                                                                        data-id_gh="<?php echo e($sp->masanpham); ?>"
                                                                        href="#">Thêm Gi<b>ỏ</b> Hàng</a></li>
                                                                <li class="wishlist"><a href="#"
                                                                        class="clickThemYt"
                                                                        data-id_yeuThich="<?php echo e($sp->masanpham); ?>"><i
                                                                            class="fa fa-heart-o"></i>Yêu Thích</a></li>
                                                                <li><a href="<?php echo e(route('chitiet', $sp->masanpham)); ?>"
                                                                        data-count="<?php echo e(count($hinh)); ?>"
                                                                        title="quick view" class="quick-view-btn"
                                                                        data-quick_id="<?php echo e($sp->masanpham); ?>"><i
                                                                            class="fa fa-eye"></i></a></li>

                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <style>
                                                .div-search {
                                                    text-align: center;
                                                    margin-top: 4rem;
                                                    margin-bottom: 4rem;
                                                }

                                                .img-search {
                                                    max-width: 100%;
                                                    position: relative;
                                                    overflow: hidden;
                                                    flex: 1 0 auto;
                                                    display: flex;
                                                    cursor: unset;
                                                    z-index: 0;
                                                    margin: auto;
                                                    border-radius: 0px;
                                                    width: 200px;
                                                    content-visibility: auto;
                                                    height: 200px !important;
                                                }

                                                .title-seach {
                                                    margin-top: 1.5rem;
                                                    font-size: 1rem;
                                                }
                                            </style>
                                            <div class="div-search col-12">
                                                <div height="200" width="200" class="img-search">
                                                    <img src="<?php echo e(asset('user/images/no-products-found.png')); ?>">
                                                </div>
                                                <div class="title-seach">Không tìm thấy sản phẩm nào</div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <!-- shop-products-wrapper end -->
                </div>
                <div class="col-lg-3 order-2 order-lg-1" style="display:<?php echo e($id == 'laptop' ? '' : 'none'); ?>;">
                    <!--sidebar-categores-box start  -->
                    <div class="sidebar-categores-box">
                        <div class="sidebar-title">
                            <h2>Bộ Lọc</h2>
                        </div>
                        <!-- btn-clear-all start -->
                        <a href="<?php echo e(route('danhsachsp', 'laptop')); ?>" class="btn-clear-all mb-sm-30 mb-xs-30">Xóa tất
                            cả</a>
                        <!-- btn-clear-all end -->
                        <form id="locform" action="<?php echo e(route('danhsachsp', 'laptop')); ?>" method="get">
                            <!-- filter-sub-area start -->
                            <div class="filter-sub-area">
                                <h5 class="filter-sub-titel">hãng sản xuất</h5>
                                <div class="categori-checkbox">
                                    <ul>
                                        <?php $__currentLoopData = $hangsx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nsx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $mahang = [];
                                                $hangsx_arr = [];
                                                if (isset($_GET['hangsx'])) {
                                                    $mahang = $_GET['hangsx'];
                                                    $hangsx_arr = explode(',', $mahang);
                                                }

                                            ?>
                                            <li>
                                                <input class="hangsx" data-locsp="hangsx" type="checkbox"
                                                    <?php echo e(in_array($nsx->mahang, $hangsx_arr) ? 'checked' : ''); ?>

                                                    name="hangsx" value="<?php echo e($nsx->mahang); ?>"><a
                                                    href="#"><?php echo e($nsx->tenhang); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <!-- filter-sub-area end -->
                            <!-- filter-sub-area start -->
                            <div class="filter-sub-area pt-sm-10 pt-xs-10">
                                <h5 class="filter-sub-titel">CPU</h5>
                                <div class="categori-checkbox">

                                    <ul>
                                        <?php
                                            $cpu = [];
                                            $cpu_arr = [];
                                            if (isset($_GET['cpu'])) {
                                                $cpu = $_GET['cpu'];
                                                $cpu_arr = explode(',', $cpu);
                                            }
                                            $arrs_cpu = ['core i3', 'core i5', 'core i7', 'ryzen 3', 'ryzen 5', 'ryzen 7'];

                                        ?>
                                        <?php $__currentLoopData = $arrs_cpu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input class="cpu" type="checkbox"
                                                    <?php echo e(in_array($arr, $cpu_arr) ? 'checked' : ''); ?> data-locsp="cpu"
                                                    name="cpu" value="<?php echo e($arr); ?>"><a href="#">Intel
                                                    <?php echo e(ucfirst($arr)); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>

                                </div>
                            </div>
                            <!-- filter-sub-area end -->
                            <!-- filter-sub-area start -->
                            <div class="filter-sub-area pt-sm-10 pt-xs-10">
                                <h5 class="filter-sub-titel">ram</h5>
                                <div class="size-checkbox">

                                    <ul>
                                        <?php
                                            $ram = [];
                                            $ram_arr = [];
                                            if (isset($_GET['ram'])) {
                                                $ram = $_GET['ram'];
                                                $ram_arr = explode(',', $ram);
                                            }
                                            $arrs_ram = ['4', '8', '16'];

                                        ?>
                                        <?php $__currentLoopData = $arrs_ram; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input class="ram" type="checkbox"
                                                    <?php echo e(in_array($arr, $ram_arr) ? 'checked' : ''); ?> data-locsp="ram"
                                                    name="ram" value="<?php echo e($arr); ?>"><a
                                                    href="#"><?php echo e($arr); ?> GB</a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>

                                </div>
                            </div>
                            <!-- filter-sub-area end -->
                            <!-- filter-sub-area start -->
                            <div class="filter-sub-area pt-sm-10 pb-sm-15 pb-xs-15">
                                <h5 class="filter-sub-titel">card đồ họa</h5>
                                <div class="categori-checkbox">
                                    <?php
                                        $carddohoa = [];
                                        $carddohoa_arr = [];
                                        if (isset($_GET['carddohoa'])) {
                                            $carddohoa = $_GET['carddohoa'];
                                            $carddohoa_arr = explode(',', $carddohoa);
                                        }
                                        $arrs_carddohoa = ['0', '1', '2'];

                                    ?>
                                    <ul>
                                        <?php $__currentLoopData = $arrs_carddohoa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input class="carddohoa" type="checkbox"
                                                    <?php echo e(in_array($arr, $carddohoa_arr) ? 'checked' : ''); ?>

                                                    data-locsp="carddohoa" name="carddohoa"
                                                    value="<?php echo e($arr); ?>"><a href="#">
                                                    <?php if($arr == 0): ?>
                                                        Onboard
                                                    <?php elseif($arr == 1): ?>
                                                        Nvidia
                                                    <?php else: ?>
                                                        AMD
                                                    <?php endif; ?>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    </ul>

                                </div>
                            </div>
                            <!-- filter-sub-area end -->
                            <!-- filter-sub-area start -->
                            <div class="filter-sub-area pt-sm-10 pb-sm-15 pb-xs-15">
                                <h5 class="filter-sub-titel">ổ cứng</h5>
                                <div class="categori-checkbox">
                                    <?php
                                        $ocung = [];
                                        $ocung_arr = [];
                                        if (isset($_GET['ocung'])) {
                                            $ocung = $_GET['ocung'];
                                            $ocung_arr = explode(',', $ocung);
                                        }
                                        $arrs_ocung = ['1', '512', '256', '128'];

                                    ?>
                                    <ul>
                                        <?php $__currentLoopData = $arrs_ocung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input class="ocung" type="checkbox"
                                                    <?php echo e(in_array($arr, $ocung_arr) ? 'checked' : ''); ?> data-locsp="ocung"
                                                    name="ocung" value="<?php echo e($arr); ?>"><a href="#">SSD
                                                    <?php echo e($arr); ?> <?php echo e($arr == 1 ? 'TB' : 'GB'); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            <!-- filter-sub-area end -->
                            <div class="filter-sub-area pt-sm-10 pb-sm-15 pb-xs-15">
                                <h5 class="filter-sub-titel">màn hình</h5>
                                <div class="categori-checkbox">
                                    <?php
                                        $manhinh = [];
                                        $manhinh_arr = [];
                                        if (isset($_GET['manhinh'])) {
                                            $manhinh = $_GET['manhinh'];
                                            $manhinh_arr = explode(',', $manhinh);
                                        }
                                        $arrs_manhinh = ['13', '14', '15'];

                                    ?>
                                    <ul>
                                        <?php $__currentLoopData = $arrs_manhinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input class="manhinh" type="checkbox"
                                                    <?php echo e(in_array($arr, $manhinh_arr) ? 'checked' : ''); ?>

                                                    data-locsp="manhinh" name="manhinh" value="<?php echo e($arr); ?>"><a
                                                    href="#">
                                                    <?php echo e($arr == 15 ? 'Trên' : 'Khoảng'); ?> <?php echo e($arr); ?> inch</a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>

                                </div>
                            </div>
                            <div class="filter-sub-area pt-sm-10 pb-sm-15 pb-xs-15">
                                <h5 class="filter-sub-titel">tình trạng</h5>
                                <div class="categori-checkbox">
                                    <?php
                                        $tinhtrang = [];
                                        $tinhtrang_arr = [];
                                        if (isset($_GET['tinhtrang'])) {
                                            $tinhtrang = $_GET['tinhtrang'];
                                            $tinhtrang_arr = explode(',', $tinhtrang);
                                        }
                                        $arrs_tinhtrang = ['0', '1'];

                                    ?>
                                    <ul>
                                        <?php $__currentLoopData = $arrs_tinhtrang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input class="tinhtrang" type="checkbox"
                                                    <?php echo e(in_array($arr, $tinhtrang_arr) ? 'checked' : ''); ?>

                                                    data-locsp="tinhtrang" name="tinhtrang"
                                                    value="<?php echo e($arr); ?>"><a href="#">
                                                    <?php echo e($arr == 0 ? 'Mới' : 'Cũ'); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>

                                </div>
                            </div>
                            <div class="filter-sub-area pt-sm-10 pb-sm-15 pb-xs-15">
                                <h5 class="filter-sub-titel">mức giá</h5>
                                <div class="categori-checkbox">
                                    <?php
                                        $mucgia = [];
                                        $mucgia_arr = [];
                                        if (isset($_GET['mucgia'])) {
                                            $mucgia = $_GET['mucgia'];
                                            $mucgia_arr = explode(',', $mucgia);
                                        }
                                        $arrs_mucgia = ['dưới 10', 'từ 10-15', 'từ 15-20', 'Từ 20-25', 'trên 25'];

                                    ?>
                                    <ul>
                                        <?php $__currentLoopData = $arrs_mucgia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input class="mucgia" type="checkbox"
                                                    <?php echo e(in_array(Str::slug($arr), $mucgia_arr) ? 'checked' : ''); ?>

                                                    data-locsp="mucgia" name="mucgia" value="<?php echo e(Str::slug($arr)); ?>"><a
                                                    href="#">
                                                    <?php echo e(ucfirst($arr)); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>

                                </div>
                            </div>
                        </form>
                    </div>
                    <!--sidebar-categores-box end  -->

                </div>
            </div>
        </div>
    </div>
    <!-- Content Wraper Area End Here -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.hangsx,.cpu,.ram,.carddohoa,.ocung,.manhinh,.tinhtrang,.mucgia').click(function() {
                var url = [],
                    temp_nsx = [],
                    temp_cpu = [],
                    temp_ram = [],
                    temp_carddohoa = [],
                    temp_ocung = [],
                    temp_manhinh = [],
                    temp_tinhtrang = [],
                    temp_mucgia = [];

                $.each($("[data-locsp='hangsx']:checked"), function() {
                    temp_nsx.push($(this).val());
                });
                temp_nsx.reverse(); // dao nguoc chuoi
                $.each($("[data-locsp='cpu']:checked"), function() {
                    temp_cpu.push($(this).val());
                });
                temp_cpu.reverse();
                $.each($("[data-locsp='ram']:checked"), function() {
                    temp_ram.push($(this).val());
                });
                temp_ram.reverse();
                $.each($("[data-locsp='ocung']:checked"), function() {
                    temp_ocung.push($(this).val());
                });
                temp_ocung.reverse();
                $.each($("[data-locsp='carddohoa']:checked"), function() {
                    temp_carddohoa.push($(this).val());
                });

                $.each($("[data-locsp='manhinh']:checked"), function() {
                    temp_manhinh.push($(this).val());
                });
                temp_manhinh.reverse();
                $.each($("[data-locsp='tinhtrang']:checked"), function() {
                    temp_tinhtrang.push($(this).val());
                });
                temp_tinhtrang.reverse();
                $.each($("[data-locsp='mucgia']:checked"), function() {
                    temp_mucgia.push($(this).val());
                });
                temp_mucgia.reverse();

                if (temp_nsx.length !== 0 || temp_cpu.length !== 0 || temp_ram.length !== 0 ||
                    temp_carddohoa.length !== 0 || temp_manhinh.length !== 0 || temp_tinhtrang.length !==
                    0 || temp_mucgia.length !== 0 || temp_ocung.length !== 0
                ) {
                    url += '?hangsx=' + temp_nsx.toString() + '&cpu=' + temp_cpu.toString() + '&ram=' +
                        temp_ram.toString() + '&ocung=' + temp_ocung.toString() + '&carddohoa=' +
                        temp_carddohoa.toString() + '&manhinh=' +
                        temp_manhinh.toString() + '&tinhtrang=' + temp_tinhtrang.toString() + '&mucgia=' +
                        temp_mucgia.toString() + '&loc=laptop';
                } else {
                    var url = '<?php echo e(Request::url()); ?>';
                    url = url.replace("&hangsx=", "");
                    window.location.href = url.replace("hangsx=&", "");
                    return false;
                }
                window.location.href = url;
            });
            $('#sapxepsp').change(function() {
                <?php if($id == 'laptop' && isset($_GET['loc'])): ?>
                    var url_cu = document.URL;
                    console.log(document.URL);
                    var url = url_cu.replace("&sapxep=", "") + "&sapxep=" + $(this).val();
                    if (url) {
                        window.location = url;
                    }
                <?php else: ?>
                    var url = $(this).val();
                    console.log(url);
                    if (url) {
                        window.location = url;
                    }
                <?php endif; ?>
                return false;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('LayoutUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pi Pj\Downloads\new\vitinhqv\resources\views/User/danhsachsp.blade.php ENDPATH**/ ?>