<?php $__env->startSection('title','Giỏ Hàng'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('User.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Shopping Cart Area Strat-->
    <div class="Shopping-cart-area pt-60 pb-60">
        <div class="container">
            <div class="row">
                <div class="col-12">

                    <div class="table-content table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="li-product-remove">xóa</th>
                                    <th class="li-product-thumbnail">hình</th>
                                    <th class="cart-product-name" style="width: 372px;">tên sản phẩm</th>
                                    <th class="li-product-price">giá</th>
                                    <th class="li-product-quantity">số lượng</th>
                                    <th class="li-product-subtotal">Tổng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $tong = 0;
                                ?>
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $tong += $sp->price * $sp->qty;
                                    ?>
                                    <tr>
                                        <td class="li-product-remove"><a href="<?php echo e(route('xoagh', $sp->rowId)); ?>"><i
                                                    class="fa fa-times"></i></a></td>
                                        <td class="li-product-thumbnail"><a href="<?php echo e(route('chitiet', $sp->id)); ?>"><img
                                                    src="<?php echo e(asset('uploads/sanpham/' . $sp->options->image)); ?>"
                                                    alt="Li's Product Image" style="width: 100px; height: 100px;"></a>
                                        </td>
                                        <td class="li-product-name" style="text-align: left;"><a class="ml-30"
                                                href="<?php echo e(route('chitiet', $sp->id)); ?>"><?php echo e($sp->name); ?></a></td>
                                        <td class="li-product-price"><span
                                                class="amount"><?php echo e(number_format($sp->price)); ?></span></td>
                                        <td class="quantity">
                                            
                                            <div class="col-12">
                                                <input data-rowid="<?php echo e($sp->rowId); ?>"
                                                    class=" col-4 cart-plus-minus-box changeSoLuong"
                                                    value="<?php echo e($sp->qty); ?>" type="number"
                                                    oninput="this.value = Math.abs(this.value)">
                                            </div>
                                        </td>
                                        <td class="product-subtotal"><span
                                                class="amount"><?php echo e(number_format($sp->price * $sp->qty)); ?></span></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="coupon-all">
                                <form action="<?php echo e(route('themmgg')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="coupon">
                                        <input required id="magiamgia" class="input-text" name="magiamgia" value=""
                                            placeholder="Mã giảm giá" type="text" pattern="[A-Za-z0-9]{3,50}"
                                            title="(Gồm các ký tự là chữ thường, in hoa hoặc số, không dấu và không khoảng cách, tối đa 50 ký tự)">
                                        <input class="button" name="submit_magiamgia" value="Áp Dụng" type="submit">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5 ml-auto">
                            <div class="cart-page-total">
                                <h2>Giỏ Hàng</h2>
                                <ul>
                                    <li>Tổng cộng <span><?php echo e(number_format($tong)); ?></span></li>
                                    <?php if(Session::has('giamgia')): ?>
                                        <?php
                                            $tongThanhtoan = $tong - Session::get('giamgia')['sotiengiam'];
                                        ?>
                                        <li>Giảm giá <span>-<?php echo e(number_format(Session::get('giamgia')['sotiengiam'])); ?></span></li>
                                    <?php endif; ?>
                                    <li class="text-danger">CẦN THANH TOÁN <span><?php echo e(number_format(isset($tongThanhtoan )? $tongThanhtoan : $tong )); ?></span>
                                    </li>
                                </ul>
                                <a style="float: right;"
                                    href="<?php echo e(Session::has('dangnhap') ? route('danhsachtt') : route('danhsachtk')); ?>">Thanh Toán</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Shopping Cart Area End-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('.changeSoLuong').change(function() {
            var soluong = $(this).val();
            var rowid = $(this).data('rowid');

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('capnhatgh')); ?>',
                data: {
                    rowid: rowid,
                    soluong: soluong
                },
                success: function(res) {
                    location.reload();
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('LayoutUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laptopshop\resources\views/User/giohang.blade.php ENDPATH**/ ?>