<div class="col-sm mb-2 mb-sm-0">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-no-gutter">
            <li class="breadcrumb-item"><a class="breadcrumb-link" href="javascript:;">Sản Phẩm</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ $tieude }}</li>
        </ol>
    </nav>


</div>


